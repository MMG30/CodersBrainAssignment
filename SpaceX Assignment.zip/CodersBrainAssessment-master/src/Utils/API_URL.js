export const RenderPage_URL = 'https://api.spacexdata.com/v3/launches?limit=100';
export const LaunchSuccess_URL = "https://api.spacexdata.com/v3/launches?limit=100&amp;launch_success=true";
export const LaunchANDLandSuccess_URL = "https://api.spacexdata.com/v3/launches?limit=100&amp;launch_success=true&amp;land_success=true"
export const ALL_URL = "https://api.spacexdata.com/v3/launches?limit=100&amp;launch_success=true&amp;land_success=true&amp;launch_year=2014"
